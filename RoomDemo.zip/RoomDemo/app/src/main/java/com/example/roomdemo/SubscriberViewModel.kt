package com.example.roomdemo

import android.util.Patterns
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.roomdemo.dp.Subscriber
import com.example.roomdemo.dp.SubscriberRepository
import kotlinx.coroutines.launch

class SubscriberViewModel(private val repository: SubscriberRepository) : ViewModel() {

    val subscribers = repository.subscribers
    private var isUpdateOrDelete = false
    private lateinit var subscriberToUpdateOrDelete:Subscriber

    val inputName = MutableLiveData<String?>()
    val inputEmail = MutableLiveData<String?>()
    val saveOrUpdateButtonText = MutableLiveData<String>()
    val clearAllOrDeleteButtonText = MutableLiveData<String>()
    private val statusMassege = MutableLiveData<Event<String>>()

    val message : LiveData<Event<String>>
        get() = statusMassege

    init {
        saveOrUpdateButtonText.value = "Save"
        clearAllOrDeleteButtonText.value = "Clear All"
    }

    fun saveOrUpdate(){
        if(inputName.value==null){
            statusMassege.value=Event("Please Enter Subscriber's Name")
        }else if(inputEmail.value==null){
            statusMassege.value = Event("Please Enter Subscriber's Email")
        }else if(!Patterns.EMAIL_ADDRESS.matcher(inputEmail.value!!).matches()){
            statusMassege.value = Event("Please Enter Valid Email address")
        }else{
         if(isUpdateOrDelete){
            subscriberToUpdateOrDelete.name = inputName.value!!
            subscriberToUpdateOrDelete.email = inputEmail.value!!
            update(subscriberToUpdateOrDelete)
        }else{
        val name :String = inputName.value!!
        val email:String = inputEmail.value!!
        insert(Subscriber(0,name, email))
        inputName.value = null
        inputEmail.value = null
        }
    }
    }

    fun clearAllOrDelete(){
        if (isUpdateOrDelete){
            delete(subscriberToUpdateOrDelete)
        }else clearAll()
    }

    fun initUpdateOrDelete(subscriber:Subscriber){
        inputName.value = subscriber.name
        inputEmail.value = subscriber.email
        isUpdateOrDelete = true
        subscriberToUpdateOrDelete = subscriber
        saveOrUpdateButtonText.value = "Update"
        clearAllOrDeleteButtonText.value = "Delete"
    }

    fun insert(subscriber: Subscriber) = viewModelScope.launch {
        val newRowId:Long=repository.insert(subscriber)
        if(newRowId>-1){
        statusMassege.value = Event("Subscriber Inserted Successfully in $newRowId Row ")
        }else{
            statusMassege.value = Event("Error Occurred")
        }
        }
    fun update(subscriber: Subscriber) = viewModelScope.launch {
        val updatedRow:Int=repository.update(subscriber)
        if(updatedRow>0){
        inputName.value = null
        inputEmail.value = null
        isUpdateOrDelete = false
        subscriberToUpdateOrDelete = subscriber
        saveOrUpdateButtonText.value = "Save"
        clearAllOrDeleteButtonText.value = "Clear All"
        statusMassege.value = Event("Subscriber Updated Successfully in $updatedRow Row")
    }else{
            statusMassege.value = Event("Error Occurred")
        }
    }
    fun delete(subscriber: Subscriber) = viewModelScope.launch {
        val deletedRow:Int = repository.delete(subscriber)
        if(deletedRow>0){
        inputName.value = null
        inputEmail.value = null
        isUpdateOrDelete = false
        subscriberToUpdateOrDelete = subscriber
        saveOrUpdateButtonText.value = "Save"
        clearAllOrDeleteButtonText.value = "Clear All"
        statusMassege.value = Event("Subscriber $deletedRow Row Deleted Successfully")
    }else{
            statusMassege.value = Event("Error Occurred")
        }
    }
    fun clearAll() = viewModelScope.launch {
       val clearAllRow:Int=repository.deleteAll()
        if(clearAllRow>0){
        statusMassege.value = Event("All $clearAllRow Subscribers Row Deleted Successfully")
    }else{
            statusMassege.value = Event("Error Occurred")
        }
    }

}